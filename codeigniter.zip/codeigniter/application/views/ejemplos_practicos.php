<div id="container">
	<h1>Ejemplos desarrollados de medidas de seguridad en CodeIgniter</h1>

	<div id="body">
	  	<li><a href="<?=site_url("formulario_ASN/index")?>">Validaci&oacute;n formularios con form_validation</a></li>
	  	<li><a href="<?=site_url("formulario_ASN/index")?>">Prevencion XSS</a></li>
	  	<li><a href="<?=site_url("welcome/validacion_CSP")?>">Generacion de encabezados de seguridad: CSP permitido contenido externo</a></li>
	  	<li><a href="<?=site_url("welcome/validacion_CSP_insegura")?>">Generacion de encabezados de seguridad: CSP no permitido contenido externo</a></li>
</div>
